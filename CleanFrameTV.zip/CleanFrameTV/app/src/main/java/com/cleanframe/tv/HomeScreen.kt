package com.cleanframe.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Background = Brush.verticalGradient(
    listOf(Color(0xFF0A0F1E), Color(0xFF16254A), Color(0xFF3B2D63), Color(0xFF6B3F6E))
)

@Composable
fun HomeScreen(apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit) {
    // The Home button on the remote should never close the launcher.
    BackHandler(enabled = true) { }

    Box(Modifier.fillMaxSize().background(Background)) {
        ClockBlock(Modifier.align(Alignment.TopStart).padding(start = 80.dp, top = 56.dp))
        AppRow(apps, onLaunch, Modifier.align(Alignment.BottomStart).padding(bottom = 72.dp))
    }
}

@Composable
private fun ClockBlock(modifier: Modifier) {
    val now by produceState(initialValue = Date()) {
        while (true) {
            value = Date()
            // wake exactly on the next minute boundary: near-zero idle cost
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val time = remember(now) {
        SimpleDateFormat(
            if (DateFormat.getTimeInstance(DateFormat.SHORT).format(now).contains("M")) "h:mm" else "HH:mm",
            Locale.getDefault()
        ).format(now)
    }
    val date = remember(now) { SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now) }

    Column(modifier) {
        BasicText(
            time,
            style = TextStyle(color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light),
        )
        BasicText(
            date.replaceFirstChar { it.uppercase() },
            style = TextStyle(color = Color(0xCCFFFFFF), fontSize = 24.sp, fontWeight = FontWeight.Normal),
        )
    }
}

@Composable
private fun AppRow(apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit, modifier: Modifier) {
    val listState = rememberLazyListState()
    val firstTile = remember { FocusRequester() }

    LaunchedEffect(apps.isNotEmpty()) {
        if (apps.isNotEmpty()) runCatching { firstTile.requestFocus() }
    }

    LazyRow(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 80.dp, vertical = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        itemsIndexed(apps, key = { _, a -> a.packageName }) { index, app ->
            AppTile(
                app = app,
                onClick = { onLaunch(app) },
                modifier = if (index == 0) Modifier.focusRequester(firstTile) else Modifier,
            )
        }
    }
}

@Composable
private fun AppTile(app: AppEntry, onClick: () -> Unit, modifier: Modifier) {
    var focused by remember { mutableStateOf(false) }

    // Only transform + alpha animate (GPU-friendly); no blur, no layout changes.
    val scale by animateFloatAsState(
        if (focused) 1.14f else 1f, tween(160, easing = FastOutSlowInEasing), label = "scale"
    )
    val labelAlpha by animateFloatAsState(
        if (focused) 1f else 0f, tween(140), label = "label"
    )

    val shape = RoundedCornerShape(30.dp)
    val glass = if (focused) {
        Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x26FFFFFF)))
    } else {
        Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x14FFFFFF)))
    }

    Column(
        modifier = Modifier.width(176.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier
                .size(176.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(shape)
                .background(glass)
                .border(
                    width = if (focused) 2.dp else 1.dp,
                    color = if (focused) Color(0xCCFFFFFF) else Color(0x40FFFFFF),
                    shape = shape,
                )
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size(104.dp).clip(RoundedCornerShape(22.dp)),
            )
        }
        BasicText(
            app.label,
            modifier = Modifier
                .padding(top = 22.dp)
                .graphicsLayer { alpha = labelAlpha },
            maxLines = 1,
            style = TextStyle(
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
            ),
        )
    }
}
