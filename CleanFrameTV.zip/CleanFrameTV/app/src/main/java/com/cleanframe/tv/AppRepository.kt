package com.cleanframe.tv

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppEntry(
    val packageName: String,
    val label: String,
    val launchIntent: Intent,
    val icon: ImageBitmap,
)

object AppRepository {

    // Apps shown first, in this order (if installed). Everything else follows A-Z.
    private val pinned = listOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.apple.atve.androidtv.appletv",
        "com.canal.android.canal",
        "fr.francetv.pluzz",
        "com.spotify.tv.android",
        "com.google.android.youtube.tvmusic",
    )

    private const val ICON_PX = 192 // small decoded bitmaps keep scrolling smooth

    suspend fun load(context: Context): List<AppEntry> = withContext(Dispatchers.Default) {
        val pm = context.packageManager

        fun query(category: String) = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(category), 0
        )

        // Prefer TV-optimised apps; fall back to regular launcher apps so nothing is missing.
        val resolved = (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != context.packageName }

        resolved.mapNotNull { ri ->
            val pkg = ri.activityInfo.packageName
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                ?: pm.getLaunchIntentForPackage(pkg)
                ?: return@mapNotNull null
            val drawable = ri.loadIcon(pm)
            val bmp: Bitmap = drawable.toBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
            AppEntry(
                packageName = pkg,
                label = ri.loadLabel(pm).toString(),
                launchIntent = intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                icon = bmp.asImageBitmap(),
            )
        }.sortedWith(
            compareBy<AppEntry> {
                val i = pinned.indexOf(it.packageName)
                if (i == -1) Int.MAX_VALUE else i
            }.thenBy { it.label.lowercase() }
        )
    }
}
