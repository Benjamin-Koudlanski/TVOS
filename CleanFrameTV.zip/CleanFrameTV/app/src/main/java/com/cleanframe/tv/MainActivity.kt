package com.cleanframe.tv

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var apps by mutableStateOf<List<AppEntry>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HomeScreen(apps = apps, onLaunch = ::launchApp)
        }
        refreshApps()
    }

    override fun onResume() {
        super.onResume()
        // Pick up apps installed/removed while we were in the background.
        refreshApps()
    }

    private fun refreshApps() {
        lifecycleScope.launch { apps = AppRepository.load(applicationContext) }
    }

    private fun launchApp(app: AppEntry) {
        try {
            startActivity(app.launchIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }
}
